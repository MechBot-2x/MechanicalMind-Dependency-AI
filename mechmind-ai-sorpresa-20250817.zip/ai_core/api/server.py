# ai_core/api/server.py
django>=4.2.11,<5.0
# Soporta: ASGI, GIS, GraphQL
