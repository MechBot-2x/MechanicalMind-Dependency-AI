# ai_core/utils/network_helpers.py
requests>=2.31.0
# Features: HTTP/2, Brotli, DoH, retry automático
