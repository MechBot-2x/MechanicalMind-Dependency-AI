--tipo "inyección SQL"

# O por correo con PGP
echo "Detalle del problema" | gpg --encrypt -r seguridad@mechmind-dwv.com
