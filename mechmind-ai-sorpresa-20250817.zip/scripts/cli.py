# scripts/cli.py
click>=8.1.7
# Plugins: Autocompletado Bash/Zsh
