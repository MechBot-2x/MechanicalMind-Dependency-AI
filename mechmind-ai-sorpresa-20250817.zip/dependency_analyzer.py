# Añadir en dependency_analyzer.py
def get_dependency_tree(self):
    """Para futuras implementaciones"""
    return {"dependencies": self.dependencies}
