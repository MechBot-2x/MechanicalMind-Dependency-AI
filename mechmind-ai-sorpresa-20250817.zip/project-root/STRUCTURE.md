```
project-root/
├── src/
│   └── your_package/
│       └── __init__.py
├── setup.py
├── pyproject.toml
└── requirements.txt
```
