Service Topology
================

.. mermaid::
   graph TD
       A[API Layer] --> B[Data Pipeline]
       A --> C[Admin Console]
       B --> D[(Knowledge Base)]
